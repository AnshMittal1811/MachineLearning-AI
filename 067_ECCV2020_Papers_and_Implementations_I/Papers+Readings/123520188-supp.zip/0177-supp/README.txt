=====================================================================
Efficient Non-Line-of-Sight Imaging from Transient Sinograms
Supplementary Material

Marika Isogawa, Dorian Chan, Ye Yuan, Kris Kitani, Matthew O'Toole
=====================================================================

This supplementary material submission includes
- 0177-supp.pdf
- 0177-movie.mp4

The video is encoded with H.264, which is natively supported on recent Mac OS and Windows.
