Title: Learning Object Relation Graph and Tentative Policy for Visual Navigation
Paper ID: 121

In "ECCV2020_121.mp4", we demonstrate following parts:
    - Overview of our proposed framework (00:05-00:26)
    - How does our Object Representation Graph (ORG) work (00:27-00:51)
    - How does our Tentative Policy Network (TPN) work (00:52-01:26)
    - Case study (01:27-02:26)
    - Failure case (02:27-02:44)
    - Results (02:44-02:57)

Thanks for your watching and looking forward to your reply!