mkdir out
convert reference_new_yellow.png -crop 440x480+72+0 +repage out/teaser_1.png
convert closest_cad_new.png -crop 440x480+72+0 +repage out/teaser_2.png
convert source2.png -crop 440x480+72+0 +repage out/teaser_3.png
convert teaser1_manifold.png -crop 440x480+72+0 +repage out/teaser_4.png
