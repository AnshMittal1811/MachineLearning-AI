#!/bin/sh

rm -f *.aux
rm -f *.out
rm -f *.sav

pdflatex 0264-supp
bibtex 0264-supp
pdflatex 0264-supp
pdflatex 0264-supp

case "$OSTYPE" in
  darwin*)  open 0264-supp.pdf ;;
  *)        gopen 0264-supp.pdf ;;
esac

rm -f *.aux
rm -f *.out
rm -f *.sav
rm -f *.ps
rm -f *.npg
#rm -f *.bbl
rm -f *.blg
rm -f *.brf
rm -f *.log
rm -f *.fls
rm -f *.fdb*
rm -rf *.bbl
