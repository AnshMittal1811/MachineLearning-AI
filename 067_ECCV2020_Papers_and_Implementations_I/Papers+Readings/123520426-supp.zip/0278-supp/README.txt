
To make a sample ECCV paper, copy the contents of this directory
somewhere, and type

 latex eccv2020submission
 bibtex eccv2020submission
 latex eccv2020submission
 latex eccv2020submission

or 

 pdflatex eccv2020submission
 bibtex eccv2020submission
 pdflatex eccv2020submission
 pdflatex eccv2020submission
