Supplementary Materials

paper id: 116
title: Multiview Detection with Feature Perspective Transformation

In the Supplementary Materials, we provide multiview pedestrian detection result visualizations on two datasets. Wildtrack, a standard multiview pedestrian detection dataset; and MultiviewX, a newly introduced synthetic dataset. 

In the two videos, we show detection visualizations of the single views, plus the ground plane (bird's eye view) pedestrian occupancy maps. The two pedestrian occupancy maps portray the scenario shapes and sizes of the two datasets. 
